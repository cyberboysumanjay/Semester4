[Lagrange Interpolation Equation Finder](https://www.dcode.fr/lagrange-interpolating-polynomial)
